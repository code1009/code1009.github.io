---
layout: default
title: 셈말짓기
nav_order: 2000
has_children: true
permalink: /docs/2000-code1009-tech
---

# 셈말짓기
{: .no_toc }

프로그래밍 관련 기술 자료를 공유 합니다.
{: .fs-6 .fw-300 }

