---
layout: default
title: 한글 코드 라이브러리(krc)
parent: 코드
nav_order: 5
---

# 한글 코드 라이브러리(krc)
{: .no_toc }

## Table of contents
{: .no_toc .text-delta }

1. TOC
{:toc}

---

## 소개
한글 코드를 편하게 사용 할 수 있는 라이브러리 입니다.

![](./hangul.jpg)

### 지원 코드
cp949  
unicode(ucs2)  
utf8  

### 위치
https://github.com/code1009/krc  
[github](https://github.com/code1009/krc){: .btn .btn-purple }


