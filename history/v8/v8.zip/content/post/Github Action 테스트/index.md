﻿---
title: Github Action 테스트
date: 2025-03-07 00:07:00+0000
categories:
    - 개발자노트
---


깃허브액션을 잘 사용을 하면 좋을것 같안데,
사용법을 잘 몰라서 연습용으로
작성한 글입니다.

자동으로 깃허브 액션이 동작되는지 테스트할겁니다.

https://github.com/ad-m/github-push-action/issues/96

에 보면

리파지트에서  
Settings > Actions > General >  
에서  

![](img.png)
  
설정하여야 합니다.


