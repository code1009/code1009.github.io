﻿---
title: nuget
date: 2025-03-18 00:00:00+0000
categories:
    - 개발자노트
---


# Nuget 설정

## Nuget Package Source 추가
![](img.png)

|항목|설정|
|---|---|
|Name|  nuget.org |
|Source|  https://api.nuget.org/v3/index.json |


## 솔루션 Nuget Package 복원

![](img2.png)
