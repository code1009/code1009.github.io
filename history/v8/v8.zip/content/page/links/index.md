﻿---
title: Links
links:
  - title: GitHub
    description: GitHub is the world's largest software development platform.
    website: https://github.com
    image: https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png
  - title: code1009의 GitHub
    description: https://github.com/code1009
    website: https://github.com/code1009
    image: https://avatars.githubusercontent.com/u/9472495?v=4
  - title: code1009의 GitHub Page
    description: https://code1009.github.io/
    website: https://code1009.github.io/
    image: https://avatars.githubusercontent.com/u/9472495?v=4
menu:
    main: 
        weight: 4
        params:
            icon: link

comments: false
---
