---
title: code1009
description: about code1009(셈말짓기)
image:

# Badge style
style:
    background: "#2a9d8f"
    color: "#fff"
---
